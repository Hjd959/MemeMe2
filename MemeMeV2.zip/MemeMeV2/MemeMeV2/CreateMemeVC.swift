//
//  ViewController.swift
//  MemeMe-1.0
//
//  Created by عبدالوهاب العنزي on 07/08/1440 AH.
//  Copyright © 1440 Abdulwahab. All rights reserved.
//

import UIKit

class CreateMemeVC: UIViewController, UIImagePickerControllerDelegate,
UINavigationControllerDelegate, UITextFieldDelegate{
    
    var topCounter = 0
    var buttomCounter = 0
    
    @IBOutlet weak var innerView: UIView!
    @IBOutlet weak var toolbar: UIToolbar!
    
    @IBOutlet weak var bouttomToolbar: UIToolbar!
    
    @IBOutlet weak var tobText: UITextField!
    
    @IBOutlet weak var bouttomText: UITextField!
    
    @IBOutlet weak var cancelButtom: UIBarButtonItem!
    
    @IBOutlet weak var shareButtom: UIBarButtonItem!
    
    @IBOutlet weak var cameraButtom: UIBarButtonItem!
    
    @IBOutlet weak var albomButtom: UIBarButtonItem!
    
    @IBOutlet weak var imageView: UIImageView!
    
    
    
    //    override var prefersStatusBarHidden: Bool {
    //        return true
    //    }
    
    
    
    var memes: [Meme]! {
        let object = UIApplication.shared.delegate
        let appDelegate = object as! AppDelegate
        return appDelegate.memes
    }
    
    var meme: Meme!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //MARK: Button setup
        cameraButtom.isEnabled = UIImagePickerController.isSourceTypeAvailable(.camera)
       
        DisableSbAndCb()
        hideNbAndTb()
        
        //MARK: Text attr. setup
        
        configureTextField(tobText, text: "TOP")
        configureTextField(bouttomText, text: "BOTTOM")
        
        tobText.textAlignment = .center
        bouttomText.textAlignment = .center
        
    }

    
    @IBAction func pickerCameraAlbom(_ sender: Any) {
        
        let buttonPressed = sender as! UIBarButtonItem
        
        let pickerController = UIImagePickerController()
        pickerController.delegate = self
        
        //If the cameraButton pressed of Albumbutton
        if buttonPressed == cameraButtom {
            pickerController.sourceType = .camera
        }
        else if buttonPressed == albomButtom {
            pickerController.sourceType = .photoLibrary
        }
        
        present(pickerController, animated: true, completion: nil)
        EnableSbAndCb()
        
    }
    
    @IBAction func Cancell(_ sender: Any) {
        
        imageView.image = nil
        
        tobText.text = "Top"
        bouttomText.text = "Bottom"
        
        DisableSbAndCb()
        
        topCounter=0
        buttomCounter=0
        
         _ = navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func chaerReist(_ sender: Any) {
        
        let memedImage = generateMemedImage()
        let activity = UIActivityViewController(activityItems: [memedImage], applicationActivities: nil)
        
        activity.completionWithItemsHandler = { (activityType, completed, returnedItems, activityError) -> Void in
            if completed {
                self.save(memedImage)
            }
        }
        present(activity, animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        
        dismiss(animated: true, completion: nil)
        
        DisableSbAndCb()
        
    }
    
    func imagePickerController(_ picker: UIImagePickerController,
                               didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]){
        
        if let image = info[.originalImage] as? UIImage {
            imageView.image = image
            
            dismiss(animated: true, completion: nil)
        }
    }
    
    func save( _ memedImage : UIImage) {
        self.meme = Meme(topText: tobText.text!, bottomText: bouttomText.text!, originalImage: imageView.image!, memedImage: memedImage)
        
        let object = UIApplication.shared.delegate
        let appDelegate = object as! AppDelegate
        
        appDelegate.memes.append(meme)
    }
    
    func generateMemedImage() -> UIImage {
        
        HideNavTool()
        UIGraphicsBeginImageContext(self.view.frame.size)
        view.drawHierarchy(in: self.view.frame, afterScreenUpdates: true)
        let memedImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        
        ShowNavTool()
        
        return memedImage
    }
    
    func ShowNavTool () {
        
        self.innerView.isHidden = false
        self.bouttomToolbar.isHidden = false
        self.toolbar.isHidden = false
    }
    
    func HideNavTool (){
        
       self.innerView.isHidden = true
        self.bouttomToolbar.isHidden = true
        self.toolbar.isHidden = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        super.viewWillAppear(animated)
        subscribeToKeyboardNotifications()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
        super.viewWillDisappear(animated)
        unsubscribeFromKeyboardNotifications()
        
    }
    
    func subscribeToKeyboardNotifications() {
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: UIResponder.keyboardWillHideNotification, object: nil)
        
    }
    
    func unsubscribeFromKeyboardNotifications() {
        
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
        
    }
    
    @objc func keyboardWillShow(_ notification:Notification) {
        
        if (bouttomText.isEditing){
            view.frame.origin.y -= getKeyboardHeight(notification)
        }
        
    }
    
    
    @objc func keyboardWillHide(_ notification:Notification) {
        
        view.frame.origin.y = 0
        
    }
    
    func getKeyboardHeight(_ notification:Notification) -> CGFloat {
        
        let userInfo = notification.userInfo
        let keyboardSize = userInfo![UIResponder.keyboardFrameEndUserInfoKey] as! NSValue // of CGRect
        return keyboardSize.cgRectValue.height
        
    }
    
    // called when 'return' key pressed. return NO to ignore
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        self.view.endEditing(true)
        return false
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        cancelButtom.isEnabled = true
        if textField == tobText && topCounter  == 0{
            textField.text = ""
            topCounter+=1
        }
        else if textField == bouttomText &&  buttomCounter == 0 {
            textField.text = ""
            buttomCounter+=1
        }
        
    }
    
    func EnableSbAndCb (){
        
        shareButtom.isEnabled = true
        cancelButtom.isEnabled = true
        
    }
    
    func DisableSbAndCb (){
        
        shareButtom.isEnabled = false
        cancelButtom.isEnabled = false
        
    }
    
    func hideNbAndTb () {
        self.tabBarController?.tabBar.isHidden = true
        self.navigationController?.navigationBar.isHidden = true
    }
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
       if string == "" {
        textField.deleteBackward() }
       else {
        textField.insertText(string.uppercased())

        }
        return false

    }
    
    
    
            
   
    
    func configureTextField(_ textField: UITextField, text: String) {
        
        textField.text = text.uppercased()
        textField.delegate = self
        textField.defaultTextAttributes = [
            .font: UIFont(name: "HelveticaNeue-CondensedBlack", size: 40)!,
            .foregroundColor: UIColor.white,
            .strokeColor: UIColor.black,
            .strokeWidth: -2.5
            
            
        ]
    }
    
}
    
    
 
