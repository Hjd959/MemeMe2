
import UIKit

class MemeCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var cellImage: UIImageView!
}
